# TamaGiga Pet 2 - This is a remake of a simple clone/ripoff of the handheld digital pet game Giga Pets and Tamagotchi.
# By Jason McCoy
*So far only compatible with iPhone 6S in portrait mode for iOS 10.

To feed the pet, simply click the heart or food and drag it to the golem.


Here is what my early xcode setup looked like:
![alt tag](http://mccoygames.com/wp-content/uploads/2016/06/Screen-Shot-2016-06-26-at-10.13.47-PM.png)


When you wait 6 seconds without feeding the pet golem. This is a randomly chosen heart.
![alt tag](http://mccoygames.com/wp-content/uploads/2016/06/Screen-Shot-2016-06-26-at-12.28.06-AM.png)

Here is a randomly chosen food that also has a nice sound effect to it as well!
![alt tag](http://mccoygames.com/wp-content/uploads/2016/06/Screen-Shot-2016-06-26-at-12.28.16-AM.png)

If you neglect your pet golem, this is what happens :'(
![alt tag](http://mccoygames.com/wp-content/uploads/2016/06/Screen-Shot-2016-06-26-at-12.28.20-AM.png)



All Photo(s) by Jason McCoy / CC BY
http://creativecommons.org/licenses/by/2.0/
